#imports
import serial

#Serial Port
class SerialPort:
    #constructor
    def __init__(self, buffsize):
        self.BUFFSIZE = buffsize

    def reconnect(self, portname, baudrate):
        self.closeConn()
        self.port = serial.Serial(portname, baudrate, timeout = 1)
        self.port.flushInput()
        self.port.flushOutput()

    def closeConn(self):
        try:
            self.port.close()
        except:
            pass

    def sendData(self,data):
        data = data + '\n'
        self.port.write(data)
        self.port.flush()

    def receiveData(self):
        data = self.port.read(self.BUFFSIZE)
        return data


----------------------------------------------
Usage:

-ON HOST PC: execute python script as 'python P2_main.py' from terminal

-ON MBED: use reset button to run the program binary
----------------------------------------------


----------------------------------------------
Misc:
-to find which com port the serial device is linked to, type the following at the terminal:
	LINUX:   'ls /dev/ttyACM*'
	MAC OSX: 'ls /dev/tty.usbmodem*'

-LINUX: You may not have permission to access the serial port by default on a Linux install. You can set your permissions to allow use of the port with the following command:'sudo chmod 666 /dev/ttyACM*'
==============================================
END
==============================================
